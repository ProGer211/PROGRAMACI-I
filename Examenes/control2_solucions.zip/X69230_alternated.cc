#include <iostream>
#include <stack>
#include <cmath>

using namespace std;

// Pre: Sigui [a1, a2, a3, a4, ... a{n-2}, a{n-1}, an] el valor inicial de s.
// Post: s=[a1, a2-a1, a3-a2+a1, a4-a3+a2-a1, ..., an-a{n-1}+a{n-2}-...]
// Funció de fita: mida de s.
void alternatedSumBelowRec(stack<int> &s)
{
    if (int(s.size()) <= 1) return;
    int x = s.top();
    s.pop();
    // Es cumpleix s = [a1, a2, a3, a4, ... a{n-2}, a{n-1}]
    alternatedSumBelowRec(s);
    // HI: s = s=[a1, a2-a1, a3-a2+a1, a4-a3+a2-a1, ..., a{n-1}-a{n-2}+a{n-3}-...]
    s.push(x - s.top());
}

// Pre: Sigui [a1, a2, a3, a4, ... a{n-2}, a{n-1}, an] el valor inicial rebut en el paràmetre s.
// Post: Retorna la pila [a1, a2-a1, a3-a2+a1, a4-a3+a2-a1, ..., an-a{n-1}+a{n-2}-...]
stack<int> alternatedSumBelow(stack<int> s)
{
    alternatedSumBelowRec(s);
    return s;
}
