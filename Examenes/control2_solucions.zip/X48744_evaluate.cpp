#include "evaluate.hpp"

// Pre: Sigui S el valor inicial de s.
// Post: S i s tenen la mateixa mida.
//       s[i..j] és el rebessat de S[i..j].
//       Els valors de s i S coincideixen a les posicions [0..i-1,j+1,..,|S|]. 
// Funció de fita: j-i
void reverse(string &s, int i, int j)
{
    if (i>=j) return;
    swap(s[i], s[j]);
    // Sigui S' el valor de s en aquest punt.
    // Es cumpleix: S i S' tenen la mateixa mida.
    //              S[i]=S'[j], S[j]=S'[i].
    //              S i S' coincideixen a totes les posicions diferents de i,j.
    reverse(s, i+1, j-1);
    // HI: S' i s tenen la mateixa mida.
    //     s[i+1..j-1] és el rebessat de S'[i-1..j+1].
    //     Els valors de s i S coincideixen a les posicions [0..i-2,j+2,..,|S|].
}

// Pre: Sigui S el valor inicial de s.
// Post: Retorna el revessat de S.
string reverse(string s)
{
    reverse(s,0,int(s.size())-1);
    return s;
}

// Pre:  t és un arbre no buit que representa una expressió correcta
//       sobre strings de lletres minúscules i els operadors Concat, Reverse.
// Post: Retorna l'avaluació de l'expressió representada per t.
// Funció de fita: mida de t.
string evaluate(const BinaryTree<string> &t)
{
    string root = t.getRoot();
    if (root == "Concat") {
        string valleft = evaluate(t.getLeft());
        // valleft és l'avaluació de l'expressió representada per t.getLeft()
        string valright = evaluate(t.getRight());
        // valright és l'avaluació de l'expressió representada per t.getRight()
        return valleft + valright;
    } else if (root == "Reverse") {
        string valleft = evaluate(t.getLeft());
        // valleft és l'avaluació de l'expressió representada per t.getLeft()
        return reverse(valleft);
    } else {
        return root;
    }
}
